"""Phase 4: skewed workload with block, cyclic, and dynamic chunk scheduling."""
import argparse
import math
import time
from harness import (emit_verify_tag, hardware_info, partitions, process_counts,
                     save_json, settings, spawn_context, stats_from_samples, package_stats)


def work_item(i: int) -> float:
    # Exactly K(i) = 1 + floor((i/40)^2) iterations (using exact integer math).
    count = 1 + (i * i) // 1600
    x = 0.1 + (i % 73) * 0.0001
    for _ in range(count):
        x = math.sin(x) + math.cos(0.5 * x) + math.sqrt(abs(x) + 1.0)
    return x


def scheduling_worker(rank: int, p: int, n: int, method: str,
                      chunk: int, counter, worker_times, checksums) -> None:
    active = 0.0
    total = 0.0
    if method == "block":
        # The partition helper gives contiguous [lo, hi) ranges.
        lo, hi = partitions(n, p)[rank]
        t0 = time.perf_counter()
        for i in range(lo, hi):
            total += work_item(i)
        active += time.perf_counter() - t0
    elif method == "cyclic":
        t0 = time.perf_counter()
        for i in range(rank, n, p):
            total += work_item(i)
        active += time.perf_counter() - t0
    elif method == "dynamic":
        while True:
            # A synchronized mp.Value('i', 0) is the shared chunk queue.
            with counter.get_lock():
                first = counter.value
                counter.value += chunk
            if first >= n:
                break
            t0 = time.perf_counter()
            for i in range(first, min(n, first + chunk)):
                total += work_item(i)
            active += time.perf_counter() - t0
    else:
        raise ValueError(method)
    worker_times[rank] = active
    checksums[rank] = total


def run_case(p: int, n: int, method: str, chunk: int, warmup: int, runs: int) -> dict:
    ctx = spawn_context()
    walls, imbalances, check_values = [], [], []
    worker_time_samples = []
    for trial in range(warmup + runs):
        index = ctx.Value('i', 0)
        worker_times = ctx.Array('d', p, lock=False)
        checksums = ctx.Array('d', p, lock=False)
        workers = [ctx.Process(target=scheduling_worker,
                               args=(rank, p, n, method, chunk, index, worker_times, checksums))
                   for rank in range(p)]
        t0 = time.perf_counter_ns()
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        ms = (time.perf_counter_ns() - t0) / 1e6
        if any(worker.exitcode != 0 for worker in workers):
            raise RuntimeError(f"Scheduling worker failed for {method} C={chunk}")
        times = list(worker_times)
        mean_time = sum(times) / p
        imbalance = max(times) / mean_time if mean_time else 1.0
        if trial >= warmup:
            walls.append(ms)
            imbalances.append(imbalance)
            worker_time_samples.append(times)
            check_values.append(sum(checksums))
    stats = stats_from_samples(walls)
    return {"method": method, "chunk": chunk if method == "dynamic" else None,
            "n": n, "p": p, **package_stats(stats),
            "lambda_imbalance": stats_from_samples(imbalances).median_ms,
            "worker_times_seconds_last": worker_time_samples[-1],
            "checksum": check_values[-1]}


def run(student_id: int, mode: str = "full") -> dict:
    hw = hardware_info()
    cfg = settings(mode)
    p, _ = process_counts(hw["logical_threads"], hw["physical_cores"], mode)
    n = cfg["sched_n"]
    methods = [("block", 0), ("cyclic", 0)] + [("dynamic", c) for c in cfg["chunks"]]
    entries = []
    for method, chunk in methods:
        entry = run_case(p, n, method, chunk, cfg["warmup"], cfg["runs"])
        entries.append(entry)
        print(f"{method:>7} C={chunk:>3}: {entry['median_ms']:.3f} ms, lambda={entry['lambda_imbalance']:.3f}", flush=True)
    baseline = entries[0]
    for item in entries:
        item["speedup_vs_block"] = baseline["median_ms"] / item["median_ms"]
        if not math.isclose(baseline["checksum"], item["checksum"], rel_tol=1e-10, abs_tol=1e-8):
            raise AssertionError(f"Schedules disagree on total work: {item['method']} {item['chunk']}")
    optimal = min((entry for entry in entries if entry["method"] == "dynamic"),
                  key=lambda entry: entry["median_ms"])
    tag = emit_verify_tag("PHASE4", student_id, baseline["median_ms"], optimal["median_ms"])
    print(tag)
    return {"phase": 4, "student_id": student_id, "mode": mode,
            "used_physical_cores": p, "n": n, "cases": entries,
            "best_chunk": optimal["chunk"], "best_dynamic_median_ms": optimal["median_ms"],
            "tag_inputs": [baseline["median_ms"], optimal["median_ms"]],
            "verify_tag": tag}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--output", default="results/phase4.json")
    args = parser.parse_args()
    save_json(args.output, run(args.student_id, args.mode))
