"""Create a complete hardware-grounded Markdown report from genuine JSON results."""
import argparse
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCES = ["harness.py", "task0_cal.py", "task1_falsesharing.py",
           "task2_scaling.py", "task3_roofline_gemm.py", "task4_scheduling.py",
           "run_all.py", "build_report.py"]


def num(x, places: int = 4) -> str:
    if x is None:
        return "N/A"
    if not math.isfinite(float(x)):
        return "N/A"
    return f"{x:.{places}f}"


def md_table(headers: list[str], rows: list[list]) -> list[str]:
    table = ["| " + " | ".join(map(str, headers)) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        table.append("| " + " | ".join(str(value) for value in row) + " |")
    return table + [""]


def format_bytes(value) -> str:
    if value is None:
        return "Unavailable"
    return f"{value:,} bytes ({value / 1024:.1f} KiB)"


def generate(results_dir: Path, output: Path) -> Path:
    data = []
    for i in range(5):
        f = results_dir / f"phase{i}.json"
        if not f.exists():
            raise FileNotFoundError(f"Missing actual hardware measurement: {f}. Run Phase {i} first.")
        data.append(json.loads(f.read_text(encoding="utf-8")))
    if len({d["student_id"] for d in data}) != 1:
        raise ValueError("Results use different Student IDs")
    if len({d["mode"] for d in data}) != 1:
        raise ValueError("Mixed run modes would make the report invalid")
    r0, r1, r2, r3, r4 = data
    mode, student_id = r0["mode"], r0["student_id"]
    hw = r0["hardware"]
    lines = [f"# Performance Evaluation and Optimization in Parallel Computing",
             "", f"Student ID: **{student_id}**", f"Run mode: **{mode}**",
             f"Measurement timestamp (UTC, Phase 0): {r0['timestamp_utc']}", "",
             "This report was generated from the recorded measurements in `results/`. "
             "Only `full` mode uses the lab-sheet workloads and the stated 2 warm-ups / 7 measured runs.", ""]
    if mode != "full":
        lines.extend(["**VALIDATION ONLY:** This is a reduced-workload test and does not satisfy the assignment's full-size measurements.", ""])
    lines.extend(["## Phase 0 — Hardware Topology and Calibration", ""])
    lines += md_table(["Hardware item", "Observed value"], [
        ["Operating system", hw["system"]],
        ["CPU model", hw["cpu_model"]],
        ["Physical cores P_phys", hw["physical_cores"]],
        ["Logical threads P_log", hw["logical_threads"]],
        ["Cache-line size", format_bytes(hw["line_bytes"])],
        ["L1 data cache", format_bytes(hw["l1d_bytes"])],
        ["L2 cache", format_bytes(hw["l2_bytes"])],
        ["L3 cache", format_bytes(hw["l3_bytes"])],
        ["perf_counter_ns() call count", r0["calls"]],
        ["Mean call latency", num(r0["mean_call_ns"], 2) + " ns"],
    ])
    if hw["notes"]:
        lines.extend(["Hardware collection notes: " + " ".join(hw["notes"]), ""])
    lines.extend(["The calibration uses one million consecutive `time.perf_counter_ns()` calls. "
                  "The mean is total elapsed nanoseconds divided by one million. "
                  "The worksheet leaves Phase 0 tag inputs unspecified; this implementation uses "
                  "(mean call latency in ns, logical CPU count).", ""])

    lines.extend(["## Phase 1 — False Sharing, Strides, Karp–Flatt", "",
                  f"Total per-trial operations: **{r1['total_operations']:,}**. "
                  f"Stride sweep process count: **{r1['used_physical_cores']}**.", ""])
    lines += md_table(["Stride (slots)", "Spacing (bytes)", "Median (ms)", "IQR (ms)", "Mops/s"], [
        [v["stride"], v["stride_bytes"], num(v["median_ms"]), num(v["iqr_ms"]), num(v["throughput_mops"])]
        for v in r1["stride_sweep"]])
    lines += md_table(["Stride", "p", "Median (ms)", "Speedup S_p", "Efficiency E_p", "Karp–Flatt e(p)"], [
        [v["stride"], v["p"], num(v["median_ms"]), num(v["speedup"]), num(v["efficiency"]), num(v["karp_flatt"])]
        for v in r1["scaling"]])
    lines.extend(["**Formulas:** Throughput = M / (T_ms × 1000) Mops/s; "
                  "S_p = T_1/T_p; E_p = S_p/p; e(p) = (1/S_p − 1/p)/(1 − 1/p) for p ≥ 2.", ""])
    shift = r1["inflection"]
    if shift:
        if shift["relative_speed_gain"] > 0:
            lines.extend([f"Largest observed adjacent-stride throughput improvement: "
                          f"**{shift['from_bytes']} → {shift['to_bytes']} bytes**, "
                          f"{num(100 * shift['relative_speed_gain'], 2)}% faster. "
                          "This is an empirical breakpoint, not proof of an exact physical cache-line boundary.", ""])
        else:
            lines.extend(["No positive adjacent-stride improvement was measured; a sharp coherence breakpoint "
                          "cannot be established from these samples.", ""])
    for stride in (1, 16):
        rows = [v for v in r1["scaling"] if v["stride"] == stride and v["karp_flatt"] is not None]
        if rows:
            lines.extend([f"At stride {stride}, Karp–Flatt e(p) changes from "
                          f"{num(rows[0]['karp_flatt'])} at p={rows[0]['p']} to "
                          f"{num(rows[-1]['karp_flatt'])} at p={rows[-1]['p']}. "
                          "The measured value reflects not only serial work, but also cache contention, "
                          "process startup, scheduling, and memory pressure.", ""])
    lines.extend(["Writes to adjacent 8-byte slots can share a cache line. Larger spacing reduces this "
                  "kind of invalidation, but performance can also depend on cache levels and core placement.", ""])

    lines.extend(["## Phase 2 — Strong Scaling vs. Weak Scaling", "",
                  f"Strong N = **{r2['strong_n']:,}**; weak N0 = **{r2['weak_n0']:,}** per process. "
                  "Stage A handles 5% serially. Stage B uses a pre-created process pool.", ""])
    lines += md_table(["p", "Strong N", "T_p (ms)", "Stage A (ms)", "Speedup", "Efficiency"], [
        [v["p"], v["n"], num(v["median_ms"]), num(v["stage_a_median_ms"]), num(v["speedup"]), num(v["efficiency"])]
        for v in r2["strong"]])
    lines += md_table(["p", "Weak N", "T_p (ms)", "Weak efficiency", "α", "Gustafson speedup"], [
        [v["p"], v["n"], num(v["median_ms"]), num(v["weak_efficiency"]), num(v["alpha"]), num(v["gustafson_speedup"])]
        for v in r2["weak"]])
    lines.extend(["**Formulas:** Strong speedup = T1_strong/Tp_strong; "
                  "strong efficiency = strong speedup/p; weak efficiency = T1_weak/Tp_weak; "
                  "α = StageA_time(p)/Tp_weak; S_Gustafson = p − α(p−1).", "",
                  f"Serial fraction from the single-process strong run: **s = {num(r2['serial_fraction'], 6)}**. "
                  f"Amdahl's asymptotic cap: **1/s = {num(r2['amdahl_cap'])}**. "
                  f"Measured S at P_log={r2['used_logical_threads']}: "
                  f"**{num(r2['strong'][-1]['speedup'])}**. "
                  "The model cap is an idealization; sampling and runtime overhead make direct comparisons approximate.", ""])
    if r2["inflection"]:
        inf = r2["inflection"]
        lines.extend([f"At the P_phys → P_phys+1 boundary (**{inf['boundary'][0]} → {inf['boundary'][1]}**), "
                      f"marginal speedup is **{num(inf['boundary_increment'])}**, versus the preceding "
                      f"increment of **{num(inf['previous_increment'])}** "
                      f"(change **{num(inf['delta_increment'])}**). "
                      "The hardware model determines whether this corresponds to SMT, P/E core transition, or neither.", ""])
    else:
        lines.extend(["The P_phys → P_phys+1 inflection was not measurable in this run because "
                      "the relevant pair of process counts is unavailable.", ""])

    lines.extend(["## Phase 3 — Empirical Roofline and Cache-Blocked GEMM", ""])
    lines += md_table(["Roofline parameter", "Measured value"], [
        ["Sustained memory bandwidth", num(r3["bandwidth"]["bandwidth_gbs"], 6) + " GB/s"],
        ["Bandwidth median", num(r3["bandwidth"]["median_ms"]) + " ms"],
        ["Sustained scalar compute", num(r3["compute"]["compute_gflops"], 6) + " GFLOP/s"],
        ["Compute median", num(r3["compute"]["median_ms"]) + " ms"],
        ["Roofline ridge intensity", num(r3["ridge_flops_per_byte"], 6) + " FLOP/byte"],
        ["Matrix dimensions", f"{r3['n']} × {r3['n']}"],
        ["Process count", r3["used_physical_cores"]],
    ])
    lines.extend(["**Formulas:** BW = 2 × buffer_bytes / T_seconds / 10⁹; "
                  "P = modeled FLOPs / T_seconds / 10⁹; ridge I* = P/BW; "
                  "GEMM performance = 2N³/T_seconds/10⁹; roofline ceiling = min(P, BW×I).", ""])
    lines += md_table(["GEMM version", "BS", "Median ms", "GFLOP/s", "Tile bytes", "I (FLOP/B)", "Roof ceiling", "Max abs. error"], [
        [v["variant"], v["bs"] if v["bs"] is not None else "–",
         num(v["median_ms"]), num(v["gflops"], 6),
         v.get("tile_footprint_bytes", "–"), num(v.get("operational_intensity")),
         num(v.get("roofline_ceiling_gflops"), 6),
         num(v.get("max_error_vs_reordered", v.get("max_error_vs_naive")) , 12)]
        for v in r3["variants"]])
    best = next(v for v in r3["variants"] if v["variant"] == "blocked" and v["bs"] == r3["best_bs"])
    lines.extend([f"Best blocked tile: **BS*={r3['best_bs']}**, measured **{num(best['gflops'], 6)} GFLOP/s**. "
                  f"Its three-tile working set is **{best['tile_footprint_bytes']:,} bytes** "
                  f"(L1d capacity: {format_bytes(hw['l1d_bytes'])}; "
                  f"L2: {format_bytes(hw['l2_bytes'])}). "
                  "A working-set fit is only a capacity estimate, not proof all accesses hit that cache.", "",
                  "All blocked variants are checked against reordered GEMM with a strict absolute tolerance "
                  "of 10⁻⁹. The matrix is double precision on flat shared buffers. "
                  "Tile operational intensity is the sheet's BS/12 approximation; actual DRAM traffic "
                  "was not measured. Consequently, a precise intensity for naive and reordered GEMM "
                  "cannot be claimed. Python interpreter overhead also separates scalar throughput "
                  "from hardware SIMD/FMA peak throughput.", ""])

    lines.extend(["## Phase 4 — Skewed Workload and Dynamic Chunk Queue", "",
                  f"N = **{r4['n']:,}**, P_phys used = **{r4['used_physical_cores']}**; "
                  "K(i) = 1 + floor((i/40)²).", ""])
    lines += md_table(["Strategy", "Chunk C", "Twall median ms", "IQR ms", "λ", "Speedup vs. block"], [
        [v["method"], v["chunk"] if v["chunk"] is not None else "–",
         num(v["median_ms"]), num(v["iqr_ms"]), num(v["lambda_imbalance"]),
         num(v["speedup_vs_block"])] for v in r4["cases"]])
    block = r4["cases"][0]
    chosen = next(v for v in r4["cases"] if v["method"] == "dynamic" and v["chunk"] == r4["best_chunk"])
    lines.extend(["**Formula:** λ = max(worker active seconds) / mean(worker active seconds). "
                  "Active time excludes time waiting for the dynamic queue lock; wall time includes process startup.", "",
                  f"Measured best dynamic chunk is **C*={r4['best_chunk']}** with **{num(chosen['median_ms'])} ms** "
                  f"against static contiguous block **{num(block['median_ms'])} ms** "
                  f"(relative speedup **{num(chosen['speedup_vs_block'])}×**).", "",
                  "At C=1, workers fetch tasks frequently, increasing synchronized-index overhead; "
                  "at C=512, each assignment contains many items, potentially leaving a costly tail. "
                  "The selected C* is the empirically fastest tested option on this machine; "
                  "it may differ with process counts and other system load.", ""])
    lines.extend(["## Hardware-bound verification hashes", "",
                  "The five lines below are preserved verbatim from the machine-generated JSON outputs. "
                  "FNV-1a inputs include phase, Student ID, logical CPU count, and the two designated "
                  "metrics rounded to four decimal places.", "", "```text"])
    lines.extend(v["verify_tag"] for v in data)
    lines.extend(["```", "", "## Verification and reproducibility", "",
                  "- Each full timing configuration uses two warm-ups and seven samples; median and IQR are stored in JSON.",
                  "- Process workers are top-level functions so macOS 'spawn' multiprocessing can import them.",
                  "- Parallel calculations use OS processes; the false-sharing, memory-copy and GEMM experiments use SharedMemory.",
                  "- Scaling also reads SharedMemory in the pool while leaving the shared buffer read-only.",
                  "- All numerical results must come from an actual local run; no benchmark timings are hard-coded.",
                  "- The run is hardware-specific; excessive CPU load, thermal throttling and startup overhead affect measurements.",
                  "", "## Complete Python source", ""])
    for filename in SOURCES:
        file = HERE / filename
        if not file.exists():
            raise FileNotFoundError(file)
        source = file.read_text(encoding="utf-8").rstrip()
        lines.extend([f"### `{filename}`", "", "```python", source, "```", ""])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    phase0 = json.loads((args.results / "phase0.json").read_text(encoding="utf-8"))
    output = args.output or HERE / f"lab_report_{phase0['student_id']}.md"
    print("Report:", generate(args.results, output))
