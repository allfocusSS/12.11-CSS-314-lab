This folder will be populated by running run_all.py on your MacBook.
