"""Standard-library timing, hardware telemetry and FNV-1a verification helpers."""
from dataclasses import asdict, dataclass
import json
import multiprocessing as mp
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import time
from typing import Callable


@dataclass
class BenchStats:
    min_ms: float
    median_ms: float
    iqr_ms: float
    samples_ms: list[float]


def stats_from_samples(samples: list[float]) -> BenchStats:
    if not samples:
        raise ValueError("No timing samples")
    ordered = sorted(samples)
    n = len(ordered)
    return BenchStats(ordered[0], ordered[n // 2],
                      ordered[(3 * n) // 4] - ordered[n // 4], ordered)


def run_benchmark(fn: Callable[[], None], warmup: int = 2, runs: int = 7) -> BenchStats:
    for _ in range(warmup):
        fn()
    samples = []
    for _ in range(runs):
        t0 = time.perf_counter_ns()
        fn()
        samples.append((time.perf_counter_ns() - t0) / 1e6)
    return stats_from_samples(samples)


def fnv1a_hash(s: str) -> int:
    h = 14695981039346656037
    for b in s.encode("utf-8"):
        h = ((h ^ b) * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return h


def emit_verify_tag(phase: str, seed: int, m1: float, m2: float) -> str:
    hw = mp.cpu_count()
    sig = fnv1a_hash(f"{phase}|{seed}|{hw}|{m1:.4f}|{m2:.4f}")
    return f"VERIFY_HASH[{phase}]: {sig:016X} (P_log={hw})"


def settings(mode: str) -> dict:
    if mode == "full":
        return {"warmup": 2, "runs": 7, "phase1_ops": 16_000_000,
                "strong_n": 1_200_000, "weak_n0": 200_000,
                "buffer_bytes": 64_000_000, "compute_flops": 60_000_000,
                "gemm_n": 256, "sched_n": 8000,
                "strides": [1, 2, 4, 8, 16, 32], "tiles": [8, 16, 32, 64, 96, 128],
                "chunks": [1, 8, 64, 512]}
    if mode == "quick":
        return {"warmup": 1, "runs": 3, "phase1_ops": 120_000,
                "strong_n": 20_000, "weak_n0": 4_000,
                "buffer_bytes": 2_000_000, "compute_flops": 200_000,
                "gemm_n": 64, "sched_n": 300,
                "strides": [1, 2, 4, 8, 16, 32], "tiles": [8, 16, 32, 64],
                "chunks": [1, 8, 64, 512]}
    if mode == "smoke":
        return {"warmup": 0, "runs": 1, "phase1_ops": 2000,
                "strong_n": 200, "weak_n0": 100,
                "buffer_bytes": 65536, "compute_flops": 3200,
                "gemm_n": 16, "sched_n": 40,
                "strides": [1, 2, 8, 16, 32], "tiles": [8, 16],
                "chunks": [1, 8, 64, 512]}
    raise ValueError(f"Unknown mode: {mode}")


def process_counts(logical: int, physical: int, mode: str) -> tuple[int, int]:
    if mode == "smoke":
        return min(physical, 2), min(logical, 2)
    if mode == "quick":
        return min(physical, 4), min(logical, 4)
    return physical, logical


def spawn_context():
    # Explicit spawn works on macOS and Linux, including on Apple Silicon.
    return mp.get_context("spawn")


def partitions(total: int, workers: int) -> list[tuple[int, int]]:
    q, r = divmod(total, workers)
    out, start = [], 0
    for rank in range(workers):
        end = start + q + (1 if rank < r else 0)
        out.append((start, end))
        start = end
    return out


def geometric_counts(logical: int) -> list[int]:
    result, p = [], 1
    while p <= logical:
        result.append(p)
        p *= 2
    if logical not in result:
        result.append(logical)
    return sorted(set(result))


def _sysctl(key: str) -> str | None:
    try:
        p = subprocess.run(["sysctl", "-n", key], capture_output=True,
                           text=True, check=False, timeout=8)
        return p.stdout.strip() if p.returncode == 0 and p.stdout.strip() else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def _as_int(v: str | None) -> int | None:
    if v is None:
        return None
    try:
        n = int(v)
        return n if n >= 0 else None
    except ValueError:
        return None


def _linux_cpu_cache() -> dict:
    result = {"line_bytes": None, "l1d_bytes": None,
              "l2_bytes": None, "l3_bytes": None}
    for base in sorted(Path("/sys/devices/system/cpu/cpu0/cache").glob("index*")):
        try:
            typ = (base / "type").read_text().strip().lower()
            level = int((base / "level").read_text().strip())
            size = (base / "size").read_text().strip().upper()
            m = re.match(r"(\d+)([KMG]?)", size)
            if not m:
                continue
            sz = int(m.group(1)) * {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3}[m.group(2)]
            if typ in ("data", "unified"):
                if level == 1 and typ == "data":
                    result["l1d_bytes"] = sz
                elif level == 2:
                    result["l2_bytes"] = sz
                elif level == 3:
                    result["l3_bytes"] = sz
            result["line_bytes"] = int((base / "coherency_line_size").read_text().strip())
        except (OSError, ValueError):
            continue
    return result


def hardware_info() -> dict:
    sysname = platform.system()
    logical = mp.cpu_count()
    info = {"system": sysname, "cpu_model": platform.processor() or "Unknown",
            "physical_cores": None, "logical_threads": logical,
            "line_bytes": None, "l1d_bytes": None, "l2_bytes": None,
            "l3_bytes": None, "notes": []}
    if sysname == "Darwin":
        info["cpu_model"] = _sysctl("machdep.cpu.brand_string") or _sysctl("hw.model") or info["cpu_model"]
        if info["cpu_model"].startswith("Mac"):
            try:
                sp = subprocess.run(["system_profiler", "SPHardwareDataType"], capture_output=True,
                                    text=True, timeout=15, check=False)
                for line in sp.stdout.splitlines():
                    if line.strip().startswith("Chip:"):
                        info["cpu_model"] = line.partition(":")[2].strip()
                        break
            except (OSError, subprocess.TimeoutExpired):
                pass
        info["physical_cores"] = _as_int(_sysctl("hw.physicalcpu"))
        info["logical_threads"] = _as_int(_sysctl("hw.logicalcpu")) or logical
        for name, key in (("line_bytes", "hw.cachelinesize"),
                          ("l1d_bytes", "hw.l1dcachesize"),
                          ("l2_bytes", "hw.l2cachesize"),
                          ("l3_bytes", "hw.l3cachesize")):
            info[name] = _as_int(_sysctl(key))
        info["notes"].append("On heterogeneous Apple CPUs, sysctl cache sizes may describe one core/cluster; L3 can be absent.")
    elif sysname == "Linux":
        try:
            lines = Path("/proc/cpuinfo").read_text().splitlines()
            for line in lines:
                if line.startswith("model name"):
                    info["cpu_model"] = line.partition(":")[2].strip()
                    break
        except OSError:
            pass
        info.update(_linux_cpu_cache())
        try:
            pairs = set()
            for path in Path("/sys/devices/system/cpu").glob("cpu[0-9]*/topology/physical_package_id"):
                cpu_dir = path.parent
                pairs.add((path.read_text().strip(), (cpu_dir / "core_id").read_text().strip()))
            info["physical_cores"] = len(pairs) if pairs else None
        except OSError:
            pass
        info["notes"].append("Linux cache sizes are sourced from cpu0 sysfs; cgroup CPU quotas may restrict usable cores.")
    elif sysname == "Windows":
        try:
            cmd = "Get-CimInstance Win32_Processor | ConvertTo-Json -Compress"
            data = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                                  capture_output=True, text=True, timeout=15, check=False)
            vals = json.loads(data.stdout)
            if isinstance(vals, dict):
                vals = [vals]
            info["physical_cores"] = sum(int(v.get("NumberOfCores") or 0) for v in vals) or None
            info["cpu_model"] = ", ".join(str(v.get("Name")) for v in vals)
            info["l2_bytes"] = sum(int(v.get("L2CacheSize") or 0) for v in vals) * 1024 or None
            info["l3_bytes"] = sum(int(v.get("L3CacheSize") or 0) for v in vals) * 1024 or None
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
    if not info["physical_cores"]:
        # os.cpu_count is only a fallback, and must be clearly labelled.
        info["physical_cores"] = logical
        info["notes"].append("Physical core detection failed; logical CPU count used as a fallback. Verify manually.")
    return info


def save_json(path: str | Path, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def package_stats(stats: BenchStats) -> dict:
    return asdict(stats)
