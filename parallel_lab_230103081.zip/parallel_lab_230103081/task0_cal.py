"""Phase 0: system topology, 1,000,000 perf_counter_ns calls, verification."""
import argparse
from datetime import datetime, timezone
import multiprocessing as mp
import time
from harness import emit_verify_tag, hardware_info, save_json


def run(student_id: int, mode: str = "full") -> dict:
    hw = hardware_info()
    count = 1_000_000  # The calibration count is fixed in every mode.
    t0 = time.perf_counter_ns()
    for _ in range(count):
        time.perf_counter_ns()
    elapsed_ns = time.perf_counter_ns() - t0
    mean_ns = elapsed_ns / count
    # Sheet does not specify Phase 0's m1 and m2: use call latency and P_log.
    tag = emit_verify_tag("PHASE0", student_id, mean_ns, float(mp.cpu_count()))
    result = {"phase": 0, "student_id": student_id, "mode": mode,
              "timestamp_utc": datetime.now(timezone.utc).isoformat(),
              "hardware": hw, "calls": count, "total_ns": elapsed_ns,
              "mean_call_ns": mean_ns, "tag_inputs": [mean_ns, float(mp.cpu_count())],
              "verify_tag": tag}
    print(f"Phase 0: CPU={hw['cpu_model']}, physical={hw['physical_cores']}, logical={hw['logical_threads']}")
    print(f"Average perf_counter_ns() call: {mean_ns:.2f} ns")
    print(tag)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--output", default="results/phase0.json")
    args = parser.parse_args()
    save_json(args.output, run(args.student_id, args.mode))
