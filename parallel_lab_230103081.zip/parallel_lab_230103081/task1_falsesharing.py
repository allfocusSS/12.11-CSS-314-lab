"""Phase 1: true multi-process false-sharing strides and Karp-Flatt diagnostics."""
import argparse
import ctypes
from multiprocessing import shared_memory
from harness import (emit_verify_tag, geometric_counts, hardware_info,
                     package_stats, process_counts, run_benchmark, save_json,
                     settings, spawn_context, partitions)

UINT64_MASK = 0xFFFFFFFFFFFFFFFF
SHARED_BYTES = 4096


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    arr = (ctypes.c_uint64 * 512).from_buffer(shm.buf)
    try:
        acc = arr[slot_idx]
        for i in range(iters):
            acc = (acc * 6364136223846793005 + (i | 1)) & UINT64_MASK
            arr[slot_idx] = acc
    finally:
        del arr
        shm.close()


def run_case(p: int, stride: int, operations: int, warmup: int, runs: int) -> dict:
    if (p - 1) * stride >= 512:
        raise ValueError(f"4096-byte block cannot fit p={p}, stride={stride}; 512 uint64 slots available")
    ctx = spawn_context()
    shm = shared_memory.SharedMemory(create=True, size=SHARED_BYTES)
    positions = partitions(operations, p)
    def trial() -> None:
        shm.buf[:] = bytes(SHARED_BYTES)
        children = [ctx.Process(target=fs_worker, args=(shm.name, rank * stride, end - start))
                    for rank, (start, end) in enumerate(positions)]
        for child in children:
            child.start()
        for child in children:
            child.join()
        if any(c.exitcode != 0 for c in children):
            raise RuntimeError("A false-sharing worker exited abnormally")
    try:
        stats = run_benchmark(trial, warmup, runs)
    finally:
        shm.close()
        shm.unlink()
    return {"p": p, "stride": stride, "stride_bytes": stride * 8,
            "operations": operations, "throughput_mops": operations / (stats.median_ms * 1000.0),
            **package_stats(stats)}


def run(student_id: int, mode: str = "full") -> dict:
    hw = hardware_info()
    cfg = settings(mode)
    physical, logical = process_counts(hw["logical_threads"], hw["physical_cores"], mode)
    if physical <= 0:
        raise ValueError("Invalid physical CPU count")
    cases = {}
    def get(p: int, stride: int) -> dict:
        key = (p, stride)
        if key not in cases:
            case = run_case(p, stride, cfg["phase1_ops"], cfg["warmup"], cfg["runs"])
            cases[key] = case
            print(f"p={p:>2}, stride={stride:>2}: {case['median_ms']:.3f} ms, {case['throughput_mops']:.3f} Mops/s", flush=True)
        return cases[key]
    stride_sweep = [get(physical, stride) for stride in cfg["strides"]]
    scaling = []
    for stride in (1, 16):
        t1 = get(1, stride)["median_ms"]
        for p in geometric_counts(logical):
            item = dict(get(p, stride))
            sp = t1 / item["median_ms"]
            item["speedup"] = sp
            item["efficiency"] = sp / p
            item["karp_flatt"] = ((1 / sp) - (1 / p)) / (1 - 1 / p) if p >= 2 else None
            scaling.append(item)
    best_change = None
    improvements = []
    for older, newer in zip(stride_sweep, stride_sweep[1:]):
        gain = older["median_ms"] / newer["median_ms"] - 1
        improvements.append({"from_bytes": older["stride_bytes"], "to_bytes": newer["stride_bytes"], "relative_speed_gain": gain})
    if improvements:
        best_change = max(improvements, key=lambda x: x["relative_speed_gain"])
    median1 = get(physical, 1)["median_ms"]
    median16 = get(physical, 16)["median_ms"]
    tag = emit_verify_tag("PHASE1", student_id, median1, median16)
    print(tag)
    return {"phase": 1, "mode": mode, "student_id": student_id,
            "actual_physical_cores": hw["physical_cores"],
            "used_physical_cores": physical, "used_logical_threads": logical,
            "total_operations": cfg["phase1_ops"], "stride_sweep": stride_sweep,
            "scaling": scaling, "inflection": best_change,
            "improvements": improvements,
            "verify_tag": tag, "tag_inputs": [median1, median16]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--output", default="results/phase1.json")
    args = parser.parse_args()
    save_json(args.output, run(args.student_id, args.mode))
