"""Run Phases 0..4 sequentially and generate a hardware-specific Markdown report."""
import argparse
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
TASKS = ["task0_cal.py", "task1_falsesharing.py", "task2_scaling.py",
         "task3_roofline_gemm.py", "task4_scheduling.py"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run pure-Python multiprocess lab on this computer")
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--start-phase", type=int, choices=range(5), default=0,
                        help="Resume from a phase; existing earlier JSON results are retained")
    args = parser.parse_args()
    results_dir = HERE / "results"
    results_dir.mkdir(exist_ok=True)
    for phase in range(args.start_phase, 5):
        path = results_dir / f"phase{phase}.json"
        print(f"\n==== PHASE {phase}: {TASKS[phase]} ({args.mode}) ====", flush=True)
        command = [sys.executable, str(HERE / TASKS[phase]),
                   "--student-id", str(args.student_id),
                   "--mode", args.mode, "--output", str(path)]
        subprocess.run(command, cwd=HERE, check=True)
        print(f"Saved actual Phase {phase} metrics: {path}", flush=True)
    print("\n==== CREATE MARKDOWN REPORT ====", flush=True)
    subprocess.run([sys.executable, str(HERE / "build_report.py"),
                    "--results", str(results_dir),
                    "--output", str(HERE / f"lab_report_{args.student_id}.md")],
                   cwd=HERE, check=True)


if __name__ == "__main__":
    main()
