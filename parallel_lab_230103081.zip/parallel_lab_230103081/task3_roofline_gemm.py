"""Phase 3: empirical memory/compute ceilings and three double-precision GEMM forms."""
import argparse
import ctypes
import math
from multiprocessing import shared_memory
from harness import (emit_verify_tag, hardware_info, package_stats, partitions,
                     process_counts, run_benchmark, save_json, settings, spawn_context)


def copy_worker(a_name: str, b_name: str, start: int, end: int) -> None:
    a = shared_memory.SharedMemory(name=a_name)
    b = shared_memory.SharedMemory(name=b_name)
    try:
        a.buf[start:end] = b.buf[start:end]
    finally:
        a.close()
        b.close()


def compute_worker(loops: int) -> None:
    # Sixteen independent Python scalar multiply-add accumulators.
    # One multiply and one add per assignment = 2 modeled FLOPs.
    x0, x1, x2, x3 = 0.1, 0.2, 0.3, 0.4
    x4, x5, x6, x7 = 0.5, 0.6, 0.7, 0.8
    x8, x9, x10, x11 = 0.9, 1.0, 1.1, 1.2
    x12, x13, x14, x15 = 1.3, 1.4, 1.5, 1.6
    for _ in range(loops):
        x0 = x0 * 0.9999999 + 0.000001
        x1 = x1 * 0.9999999 + 0.000001
        x2 = x2 * 0.9999999 + 0.000001
        x3 = x3 * 0.9999999 + 0.000001
        x4 = x4 * 0.9999999 + 0.000001
        x5 = x5 * 0.9999999 + 0.000001
        x6 = x6 * 0.9999999 + 0.000001
        x7 = x7 * 0.9999999 + 0.000001
        x8 = x8 * 0.9999999 + 0.000001
        x9 = x9 * 0.9999999 + 0.000001
        x10 = x10 * 0.9999999 + 0.000001
        x11 = x11 * 0.9999999 + 0.000001
        x12 = x12 * 0.9999999 + 0.000001
        x13 = x13 * 0.9999999 + 0.000001
        x14 = x14 * 0.9999999 + 0.000001
        x15 = x15 * 0.9999999 + 0.000001
    # Calculated quantity is deliberately used; Python doesn't elide scalar work.
    if not math.isfinite(x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 + x13 + x14 + x15):
        raise ArithmeticError("Non-finite compute result")


def start_and_join(ctx, target, args_list: list[tuple]) -> None:
    jobs = [ctx.Process(target=target, args=args) for args in args_list]
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()
    if any(j.exitcode != 0 for j in jobs):
        raise RuntimeError(f"Worker failed: {target.__name__}")


def measure_bandwidth(p: int, nbytes: int, warmup: int, runs: int) -> dict:
    a = shared_memory.SharedMemory(create=True, size=nbytes)
    b = shared_memory.SharedMemory(create=True, size=nbytes)
    ctx = spawn_context()
    bounds = partitions(nbytes, p)
    args = [(a.name, b.name, lo, hi) for lo, hi in bounds]
    # Ensure source is initialized (SharedMemory is zero-filled on creation).
    try:
        stats = run_benchmark(lambda: start_and_join(ctx, copy_worker, args), warmup, runs)
    finally:
        a.close()
        a.unlink()
        b.close()
        b.unlink()
    bw = (2 * nbytes) / (stats.median_ms / 1000) / 1e9
    return {"buffer_bytes_each": nbytes, "total_traffic_bytes": 2 * nbytes,
            "bandwidth_gbs": bw, **package_stats(stats)}


def measure_compute(p: int, desired_flops: int, warmup: int, runs: int) -> dict:
    ctx = spawn_context()
    loops = math.ceil(desired_flops / 32)
    flops_per_worker = 32 * loops
    args = [(loops,) for _ in range(p)]
    stats = run_benchmark(lambda: start_and_join(ctx, compute_worker, args), warmup, runs)
    return {"flops_per_worker": flops_per_worker, "total_flops": flops_per_worker * p,
            "compute_gflops": (flops_per_worker * p) / (stats.median_ms / 1000) / 1e9,
            **package_stats(stats)}


def gemm_worker(name: str, n: int, row_start: int, row_end: int,
                variant: str, bs: int) -> None:
    shm = shared_memory.SharedMemory(name=name)
    count = n * n
    arr = (ctypes.c_double * (3 * count)).from_buffer(shm.buf)
    ab = 0
    bb = count
    cb = 2 * count
    try:
        if variant == "naive":
            for i in range(row_start, row_end):
                line = i * n
                for j in range(n):
                    acc = 0.0
                    for k in range(n):
                        acc += arr[ab + line + k] * arr[bb + k * n + j]
                    arr[cb + line + j] = acc
        elif variant == "reordered":
            for i in range(row_start, row_end):
                line = i * n
                for k in range(n):
                    aik = arr[ab + line + k]
                    brow = bb + k * n
                    for j in range(n):
                        off = cb + line + j
                        arr[off] += aik * arr[brow + j]
        elif variant == "blocked":
            # 6 loops: tile ii, jj, kk, followed by micro i, k, j.
            for ii in range(row_start, row_end, bs):
                i_end = min(ii + bs, row_end)
                for jj in range(0, n, bs):
                    j_end = min(jj + bs, n)
                    for kk in range(0, n, bs):
                        k_end = min(kk + bs, n)
                        for i in range(ii, i_end):
                            line = i * n
                            for k in range(kk, k_end):
                                aik = arr[ab + line + k]
                                brow = bb + k * n
                                for j in range(jj, j_end):
                                    off = cb + line + j
                                    arr[off] += aik * arr[brow + j]
        else:
            raise ValueError(f"Unknown GEMM variant {variant}")
    finally:
        del arr
        shm.close()


def gemm_case(shm, n: int, p: int, variant: str, bs: int,
              warmup: int, runs: int) -> tuple[dict, list[float]]:
    ctx = spawn_context()
    args = [(shm.name, n, lo, hi, variant, bs) for lo, hi in partitions(n, p)]
    c_offset = 2 * n * n * 8
    zero = bytes(n * n * 8)
    def trial() -> None:
        # Output clearing is small and included in the trial time.
        shm.buf[c_offset:c_offset + len(zero)] = zero
        start_and_join(ctx, gemm_worker, args)
    stats = run_benchmark(trial, warmup, runs)
    output = list(shm.buf[c_offset:c_offset + n * n * 8].cast("d"))
    gflops = (2 * n ** 3) / (stats.median_ms / 1000.0) / 1e9
    item = {"variant": variant, "bs": bs if variant == "blocked" else None,
            "gflops": gflops, **package_stats(stats)}
    if variant == "blocked":
        item["tile_footprint_bytes"] = 3 * bs * bs * 8
        item["operational_intensity"] = bs / 12.0
    return item, output


def max_error(reference: list[float], actual: list[float]) -> float:
    if len(reference) != len(actual):
        raise ValueError("Different output sizes")
    return max((abs(a - b) for a, b in zip(reference, actual)), default=0.0)


def run(student_id: int, mode: str = "full") -> dict:
    hw = hardware_info()
    cfg = settings(mode)
    p, _ = process_counts(hw["logical_threads"], hw["physical_cores"], mode)
    bw = measure_bandwidth(p, cfg["buffer_bytes"], cfg["warmup"], cfg["runs"])
    print(f"Memory bandwidth: {bw['bandwidth_gbs']:.3f} GB/s", flush=True)
    compute = measure_compute(p, cfg["compute_flops"], cfg["warmup"], cfg["runs"])
    print(f"Scalar compute: {compute['compute_gflops']:.5f} GFLOP/s", flush=True)
    ridge = compute["compute_gflops"] / bw["bandwidth_gbs"] if bw["bandwidth_gbs"] else float("inf")
    n = cfg["gemm_n"]
    shm = shared_memory.SharedMemory(create=True, size=3 * n * n * 8)
    matrix_count = n * n
    try:
        arr = (ctypes.c_double * (3 * matrix_count)).from_buffer(shm.buf)
        for i in range(n):
            for j in range(n):
                arr[i * n + j] = ((i * 13 + j * 7) % 19 - 9) / 19.0
                arr[matrix_count + i * n + j] = ((i * 11 - j * 5) % 23 - 11) / 23.0
        del arr
        variants = []
        naïve, ref = gemm_case(shm, n, p, "naive", 0, cfg["warmup"], cfg["runs"])
        variants.append(naïve)
        print(f"GEMM naive: {naïve['median_ms']:.3f} ms", flush=True)
        reordered, reordered_output = gemm_case(shm, n, p, "reordered", 0, cfg["warmup"], cfg["runs"])
        reordered["max_error_vs_naive"] = max_error(ref, reordered_output)
        variants.append(reordered)
        for bs in cfg["tiles"]:
            entry, actual = gemm_case(shm, n, p, "blocked", bs, cfg["warmup"], cfg["runs"])
            entry["max_error_vs_reordered"] = max_error(reordered_output, actual)
            entry["max_error_vs_naive"] = max_error(ref, actual)
            entry["roofline_ceiling_gflops"] = min(compute["compute_gflops"], bw["bandwidth_gbs"] * entry["operational_intensity"])
            if entry["max_error_vs_reordered"] >= 1e-9:
                raise AssertionError(f"GEMM verification failed for BS={bs}: {entry['max_error_vs_reordered']}")
            variants.append(entry)
            print(f"GEMM blocked BS={bs:>3}: {entry['median_ms']:.3f} ms, error={entry['max_error_vs_reordered']:.2g}", flush=True)
    finally:
        shm.close()
        shm.unlink()
    if reordered["max_error_vs_naive"] >= 1e-9:
        raise AssertionError("Reordered GEMM does not match naive baseline")
    best = max((v for v in variants if v["variant"] == "blocked"), key=lambda v: v["gflops"])
    tag = emit_verify_tag("PHASE3", student_id, naïve["gflops"], best["gflops"])
    print(tag)
    return {"phase": 3, "student_id": student_id, "mode": mode,
            "used_physical_cores": p, "n": n, "bandwidth": bw,
            "compute": compute, "ridge_flops_per_byte": ridge,
            "variants": variants, "best_bs": best["bs"],
            "best_blocked_gflops": best["gflops"],
            "tag_inputs": [naïve["gflops"], best["gflops"]],
            "verify_tag": tag}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--output", default="results/phase3.json")
    args = parser.parse_args()
    save_json(args.output, run(args.student_id, args.mode))
