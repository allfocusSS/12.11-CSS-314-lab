# Performance Evaluation and Optimization in Parallel Computing

Pure Python 3 implementation for the five phases in `parallelcomputingpythonminimallab.pdf`. Uses the Python standard library only. **No benchmark results are fabricated.** CPU topology and measured timings are collected on the computer where you actually run it.

## MacBook: how to run

1. Unzip the folder, open **Terminal**, and go to the folder containing `run_all.py`, e.g. `cd ~/Downloads/parallel_lab_230103081`.
2. Check Python: `python3 --version` (Python 3.10+ recommended).
3. Disconnect the network if following the worksheet's offline execution requirement.
4. Run a very small functional check first:

   ```bash
   python3 run_all.py --student-id 230103081 --mode smoke
   ```

5. Run real complete experiments (CPU-heavy and potentially lengthy, particularly phases 1–4):

   ```bash
   python3 run_all.py --student-id 230103081 --mode full
   ```

6. Find the report `lab_report_230103081.md` and measured phase files `results/phase0.json` through `results/phase4.json`.

   Each phase saves its result as soon as it finishes. After an interruption, resume (e.g. after phases 0–2):

   ```bash
   python3 run_all.py --student-id 230103081 --mode full --start-phase 3
   ```

   **Warning:** Running `smoke` writes reduced-size demo results to the same JSON paths as full mode. If you need the real report, run full mode from Phase 0 with no `--start-phase` or make sure all previous files were already generated in full mode. You cannot combine smoke/quick with full results.

## Files

- `harness.py` — timing, hardware detection, 64-bit FNV-1a hash.
- `task0_cal.py` — Phase 0, one million timer calls.
- `task1_falsesharing.py` — Phase 1, 4096-byte SharedMemory with cache-line stride tests and Karp–Flatt.
- `task2_scaling.py` — Phase 2, persistent `multiprocessing.Pool` strong and weak scaling.
- `task3_roofline_gemm.py` — Phase 3, bandwidth, scalar compute ceiling, three GEMM variants, tile sweep, verification.
- `task4_scheduling.py` — Phase 4, contiguous/cyclic/dynamic schedules and worker imbalance.
- `build_report.py` — combines results into report and embeds **all** source code.
- `run_all.py` — runs each phase in order.

## Exact full-mode parameters

- Warm-up 2, 7 measured iterations for each configuration.
- Phase 1: 16,000,000 integer RMW steps across processes, shared 4096 bytes, strides 1/2/4/8/16/32.
- Phase 2: strong N=1,200,000 and weak per-worker N0=200,000, all integer process counts 1 through P_log.
- Phase 3: two 64-million-byte buffers, modeled 60 million FLOPs per worker, GEMM N=256, blocked tile sizes 8/16/32/64/96/128.
- Phase 4: N=8000, dynamic chunk sizes 1/8/64/512.

**Hardware cautions:** full mode assumes the supplied 4096-byte false-sharing buffer fits all `(P_phys − 1) × 32` slots. That requires `P_phys ≤ 16`. If your hardware has more cores, the worksheet is internally incompatible with the fixed buffer and largest requested stride; the script will explicitly report an error instead of silently changing the task. SharedMemory in Phase 3 requires more than 128MB available to the OS; on macOS it is usually available, but some containers have `/dev/shm` limits.

**Interpretation cautions:** Spawn and pool overhead can distort Python timings. A Python `a*b+c` scalar instruction is not a hardware FMA instruction; its 2-FLOP accounting is a *modeled* throughput for comparison, **not** a measurement of the processor's native peak. Apple's `sysctl` cache reporting and hybrid core architectures can differ from textbook assumptions.

## Academic instruction reminder

The original worksheet explicitly says "No AI Tools". These files were AI-assisted reference code and **should not be represented as produced without AI**. Follow your instructor's requirements for permitted help and submissions.
