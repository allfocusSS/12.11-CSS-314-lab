#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "Running full, hardware-bound Parallel Computing Lab for Student 230103081..."
python3 run_all.py --student-id 230103081 --mode full
echo ""
echo "Completed. Report: lab_report_230103081.md"
