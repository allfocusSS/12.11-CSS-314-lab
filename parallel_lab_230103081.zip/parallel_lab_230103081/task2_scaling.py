"""Phase 2: real process-pool strong and weak scaling with a serial stage."""
import argparse
import ctypes
import math
from multiprocessing import shared_memory
import time
from harness import (emit_verify_tag, hardware_info, package_stats, partitions,
                     process_counts, save_json, settings, spawn_context, stats_from_samples)


def stage_a(shm_buf, n: int) -> float:
    # Exactly 5% of N elements. Five sin + five sqrt operations per element.
    data = shm_buf.cast("d")
    result = 0.0
    try:
        for i in range(n // 20):
            x = data[i] + 0.01 + (i % 97) * 0.00001
            for _ in range(5):
                x = math.sin(x + 0.1)
                x = math.sqrt(abs(x) + 1.0)
            result += x
    finally:
        del data
    return result


def stage_b_worker(args: tuple) -> float:
    shm_name, n, begin, end = args
    shm = shared_memory.SharedMemory(name=shm_name)
    values = (ctypes.c_double * n).from_buffer(shm.buf)
    result = 0.0
    try:
        for i in range(begin, end):
            x = values[i] + 0.001 + (i % 113) * 0.00001
            # 10 groups of sin, cos, and scalar multiply-add = 30 units.
            for _ in range(10):
                x = math.sin(x) + math.cos(x * 0.5) + x * 0.00001
            result += x
    finally:
        del values
        shm.close()
    return result


def run_case(n: int, p: int, warmup: int, runs: int) -> dict:
    ctx = spawn_context()
    shm = shared_memory.SharedMemory(create=True, size=n * 8)
    args = [(shm.name, n, lo, hi) for lo, hi in partitions(n, p)]
    elapsed = []
    serial_elapsed = []
    checksums = []
    try:
        # Pool creation is explicitly OUTSIDE the timed loop.
        with ctx.Pool(processes=p) as pool:
            for trial in range(warmup + runs):
                t0 = time.perf_counter_ns()
                first = stage_a(shm.buf, n)
                t1 = time.perf_counter_ns()
                # Map exactly p chunks, with no shared writes in Stage B.
                parts = pool.map(stage_b_worker, args, chunksize=1)
                t2 = time.perf_counter_ns()
                if trial >= warmup:
                    elapsed.append((t2 - t0) / 1e6)
                    serial_elapsed.append((t1 - t0) / 1e6)
                    checksums.append(first + sum(parts))
    finally:
        shm.close()
        shm.unlink()
    bench = stats_from_samples(elapsed)
    return {"p": p, "n": n, **package_stats(bench),
            "stage_a_median_ms": stats_from_samples(serial_elapsed).median_ms,
            "checksum": checksums[-1]}


def run(student_id: int, mode: str = "full") -> dict:
    hw = hardware_info()
    cfg = settings(mode)
    physical, logical = process_counts(hw["logical_threads"], hw["physical_cores"], mode)
    strong = []
    for p in range(1, logical + 1):
        case = run_case(cfg["strong_n"], p, cfg["warmup"], cfg["runs"])
        strong.append(case)
        print(f"Strong p={p:>2}: {case['median_ms']:.3f} ms", flush=True)
    t1s = strong[0]["median_ms"]
    for row in strong:
        row["speedup"] = t1s / row["median_ms"]
        row["efficiency"] = row["speedup"] / row["p"]
    serial_fraction = strong[0]["stage_a_median_ms"] / t1s
    amdahl_cap = 1 / serial_fraction if serial_fraction else float("inf")

    weak = []
    for p in range(1, logical + 1):
        case = run_case(p * cfg["weak_n0"], p, cfg["warmup"], cfg["runs"])
        weak.append(case)
        print(f"Weak   p={p:>2}: {case['median_ms']:.3f} ms", flush=True)
    t1w = weak[0]["median_ms"]
    for row in weak:
        p = row["p"]
        row["weak_efficiency"] = t1w / row["median_ms"]
        row["alpha"] = row["stage_a_median_ms"] / row["median_ms"]
        row["gustafson_speedup"] = p - row["alpha"] * (p - 1)
    inflection = None
    if 1 < physical < logical:
        before = strong[physical - 1]["speedup"] - strong[physical - 2]["speedup"]
        after = strong[physical]["speedup"] - strong[physical - 1]["speedup"]
        inflection = {"boundary": [physical, physical + 1],
                      "previous_increment": before, "boundary_increment": after,
                      "delta_increment": after - before}
    tag = emit_verify_tag("PHASE2", student_id, strong[-1]["speedup"], weak[-1]["gustafson_speedup"])
    print(tag)
    return {"phase": 2, "student_id": student_id, "mode": mode,
            "used_physical_cores": physical, "used_logical_threads": logical,
            "strong_n": cfg["strong_n"], "weak_n0": cfg["weak_n0"],
            "strong": strong, "weak": weak, "serial_fraction": serial_fraction,
            "amdahl_cap": amdahl_cap, "inflection": inflection,
            "tag_inputs": [strong[-1]["speedup"], weak[-1]["gustafson_speedup"]],
            "verify_tag": tag}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", type=int, required=True)
    parser.add_argument("--mode", choices=["full", "quick", "smoke"], default="full")
    parser.add_argument("--output", default="results/phase2.json")
    args = parser.parse_args()
    save_json(args.output, run(args.student_id, args.mode))
