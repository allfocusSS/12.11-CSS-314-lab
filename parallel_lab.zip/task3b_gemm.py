"""Phase 3B: shared double-precision i-j-k, i-k-j and 6-loop tiled GEMM."""
import math
import multiprocessing as mp
from multiprocessing import shared_memory
from multiprocessing.util import Finalize
import os
from harness import (read_json,write_json,cli_parser,run_benchmark,emit_verify_tag)

_A=_B=_C=None
_AS=_BS=_CS=None


def matrix_initializer(a,b,c):
    global _A,_B,_C,_AS,_BS,_CS
    _AS=shared_memory.SharedMemory(name=a)
    _BS=shared_memory.SharedMemory(name=b)
    _CS=shared_memory.SharedMemory(name=c)
    _A=_AS.buf.cast('d')
    _B=_BS.buf.cast('d')
    _C=_CS.buf.cast('d')
    # Pool workers must release every exported memoryview before closing
    # its SharedMemory handle. A positive-priority Finalize runs before
    # interpreter teardown, avoiding BufferError in SharedMemory.__del__.
    Finalize(None, release_matrix_views, exitpriority=10)


def release_matrix_views():
    global _A, _B, _C, _AS, _BS, _CS
    # Release views before closing the backing SharedMemory objects.
    _A = _B = _C = None
    for shm in (_AS, _BS, _CS):
        if shm is not None:
            shm.close()
    _AS = _BS = _CS = None


def gemm_worker(args):
    strategy,start,end,n,bs=args
    A=_A; B=_B; C=_C
    if strategy=='naive':
        for i in range(start,end):
            row=i*n
            for j in range(n):
                z=0.0
                for k in range(n):
                    z+=A[row+k]*B[k*n+j]
                C[row+j]=z
    elif strategy=='reordered':
        for i in range(start,end):
            row=i*n
            for j in range(n): C[row+j]=0.0
            for k in range(n):
                a=A[row+k]; brow=k*n
                for j in range(n): C[row+j]+=a*B[brow+j]
    elif strategy=='blocked':
        for i in range(start,end):
            row=i*n
            for j in range(n): C[row+j]=0.0
        # Six loops ii,jj,kk,i,k,j; different workers own disjoint row ranges.
        for ii in range(start,end,bs):
            imax=min(ii+bs,end)
            for jj in range(0,n,bs):
                jmax=min(jj+bs,n)
                for kk in range(0,n,bs):
                    kmax=min(kk+bs,n)
                    for i in range(ii,imax):
                        row=i*n
                        for k in range(kk,kmax):
                            a=A[row+k]; brow=k*n
                            for j in range(jj,jmax):
                                C[row+j]+=a*B[brow+j]
    else:
        raise ValueError(strategy)
    return end-start


def main():
    args=cli_parser(__doc__).parse_args()
    data_dir=os.path.dirname(args.output)
    hw=read_json(os.path.join(data_dir,'phase0.json'))['hardware']
    roof=read_json(os.path.join(data_dir,'phase3a.json'))
    phys=int(hw['physical_cores']); logical=int(hw['logical_threads'])
    true_logical=logical
    if args.mode=='smoke': phys=min(phys,2); logical=min(logical,2)
    n=384 if args.mode=='full' else 24
    tiles=[4,8,12,16,24,32,48,64,96,128]
    warmup,timed=(1,5) if args.mode=='full' else (0,1)
    ctx=mp.get_context('spawn')
    length=n*n*8
    mems=[shared_memory.SharedMemory(create=True,size=length) for _ in range(3)]
    ma,mb,mc=mems
    a=ma.buf.cast('d'); b=mb.buf.cast('d'); c=mc.buf.cast('d')
    for i in range(n):
        for j in range(n):
            a[i*n+j]=((17*i+13*j)%97-48)/97.0
            b[i*n+j]=((11*i+19*j)%89-44)/89.0
    del a,b,c
    jobs=[(i*n//phys,(i+1)*n//phys) for i in range(phys)]
    results=[]
    baseline=None
    try:
        with ctx.Pool(phys,initializer=matrix_initializer,
                      initargs=(ma.name,mb.name,mc.name)) as pool:
            def run_variant(strategy,bs):
                work=[(strategy,s,e,n,bs) for s,e in jobs]
                def trial():
                    finished=pool.map(gemm_worker,work)
                    if sum(finished)!=n: raise RuntimeError('Missing matrix output rows')
                stats=run_benchmark(trial,warmup,timed)
                out=mc.buf.cast('d')
                measured=list(out)
                del out
                gflops=(2*n**3)/(stats.median_ms*1e6)
                return {'variant':strategy,'BS':bs,'median_ms':stats.median_ms,
                        'iqr_ms':stats.iqr_ms,'gflops':gflops},measured

            for strategy,bs in [('naive',None),('reordered',None)]+[('blocked',x) for x in tiles]:
                row,output=run_variant(strategy,bs)
                if strategy=='reordered': baseline=output
                if strategy=='blocked':
                    row['validation_max_abs_error']=max(abs(x-y) for x,y in zip(baseline,output))
                    row['equivalent_to_reordered']=row['validation_max_abs_error']<1e-9
                    if not row['equivalent_to_reordered']:
                        raise RuntimeError(f'Blocked result differs from reordered for BS={bs}: {row["validation_max_abs_error"]}')
                results.append(row)
                print(f'{strategy:9s} BS={str(bs):>4s}: {row["median_ms"]:.3f}ms {gflops_str(row)}',flush=True)
    finally:
        for shm in mems:
            shm.close(); shm.unlink()

    best=max((row for row in results if row['variant']=='blocked'),key=lambda r:r['gflops'])
    B=roof['bandwidth_gbps']; P=roof['compute_gflops']
    for row in results:
        if row['variant']=='blocked':
            bs=row['BS']; intensity=bs/12.0
            row['tile_working_set_bytes']=3*bs*bs*8
        else:
            # Assignment supplies only naive=0.125, not reordered intensity.
            # Reordered is assigned a conservative nominal comparison point.
            intensity=0.125
        roofmax=min(P,B*intensity)
        row['assumed_intensity_flops_per_byte']=intensity
        row['roofline_attainable_gflops']=roofmax
        row['roofline_attainment_pct']=100*row['gflops']/roofmax if roofmax>0 else None
    verify=emit_verify_tag('PHASE3',args.student_id,results[0]['gflops'],best['gflops'],true_logical)
    print(f'OPTIMAL_BS={best["BS"]} BEST_GFLOPS={best["gflops"]:.6f}',flush=True)
    print(verify)
    write_json(args.output,{'phase':3,'mode':args.mode,'student_id':args.student_id,
         'N':n,'p':phys,'warmups':warmup,'timed_runs':timed,'variants':results,
         'best_bs':best['BS'],'best_gflops':best['gflops'],
         'intensity_naive':0.125,'intensity_best':best['BS']/12.0,
         'verify_hash':verify,
         'limitations':'The prompt does not specify Variant 2 operational intensity; 0.125 is an explicitly labeled nominal comparison, not measured DRAM traffic.'})


def gflops_str(r):
    return f'{r["gflops"]:.6f} GFLOP/s'

if __name__=='__main__':
    mp.freeze_support()
    main()
