"""Generate the English Markdown report from ACTUAL local JSON measurements."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
from harness import read_json


def num(x,places=4):
    if x is None: return 'Not available'
    return f'{x:,.{places}f}'


def raw(x):
    return 'Not measured' if x is None else str(x)


def md_table(headers,rows):
    def sanitize(x):
        return str(x).replace('|','\\|').replace('\n',' ')
    out=['| '+' | '.join(map(sanitize,headers))+' |',
         '| '+' | '.join('---' for _ in headers)+' |']
    out.extend('| '+' | '.join(map(sanitize,row))+' |' for row in rows)
    return '\n'.join(out)+'\n'


def data_or_none(folder,key):
    path=Path(folder)/(key+'.json')
    return read_json(path) if path.exists() else None


def format_bytes(value):
    if value is None: return 'Not reported by OS'
    return f'{value} B ({value/1024:.1f} KiB)'


def generate(results_dir,student_id,outfile,source_dir,include_source=True):
    d={x:data_or_none(results_dir,x) for x in ['phase0','phase1','phase2','phase3a','phase3b','phase4']}
    available=[k for k,x in d.items() if x is not None]
    full=len(available)==6 and all(x.get('mode')=='full' for x in d.values())
    smoke=any(x and x.get('mode')=='smoke' for x in d.values())
    lines=[]
    add=lambda s='':lines.append(s)
    add(f'# Performance Evaluation and Optimization in Parallel Computing — Solo Python Systems Lab')
    add(f'**Student ID:** {student_id}  ')
    add(f'**Report creation (UTC):** {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")}  ')
    add('**Execution mode:** '+('FULL hardware measurements' if full else 'SMOKE VALIDATION ONLY — NOT FOR SUBMISSION' if smoke else 'INCOMPLETE — requires local measurements')+'  ')
    add('**Experiment environment:** local Python 3 and standard library; `multiprocessing`, `shared_memory`, `ctypes`, `time`, `math`.')
    add()
    if not full:
        add('> **Incomplete evidence warning:** This document does not claim to contain a completed 120-minute lab. No missing performance metrics have been invented. Run `python3 run_all.py --student-id '+str(student_id)+' --mode full` on the assigned laptop to produce the complete hardware-specific report.')
        add()
    add('## 0. Hardware topology, calibration, and verification')
    p0=d['phase0']
    if p0:
        h=p0['hardware']
        add(md_table(['Hardware parameter','Measured value'],[
            ('CPU model string',h['cpu_model']),('Physical CPU cores (P_phys)',h['physical_cores']),
            ('Logical hardware threads (P_log)',h['logical_threads']),
            ('Cache line size (L_bytes)',format_bytes(h.get('cacheline_bytes'))),
            ('L1 data cache',format_bytes(h.get('l1d_bytes'))),
            ('L2 cache',format_bytes(h.get('l2_bytes'))),
            ('Shared L3 / system cache',format_bytes(h.get('l3_bytes'))),
            ('Python version',h['python_version']),('Operating system',h['os']),
            ('Hybrid core-level information',h.get('core_clusters',{})),
            ]))
        add(f'The average clock call latency is estimated from {p0["clock_reads"]:,} calls to `time.perf_counter_ns()`. An empty-loop reference is subtracted to reduce Python loop overhead:')
        add(f'\n`avg clock latency = (gross benchmark time - empty-loop time) / count = {num(p0["clock_read_latency_ns"])} ns/call`.')
        add(f'Gross call cost: {num(p0["clock_gross_ns_per_read"])} ns/call; empty loop: {num(p0["empty_loop_ns_per_iteration"])} ns/iteration.')
        if h.get('physical_cores_source'): add(f'**Hardware check needed:** {h["physical_cores_source"]}.')
        if not h.get('l3_bytes'):
            add('**Cache caveat:** The OS does not expose an L3 cache size through the queried interface; this cannot be replaced with a guessed value. On Apple Silicon, some caches are shared system-level caches rather than a conventional x86 L3.')
    else: add('**Phase 0 measurements missing.**')
    add('### Integrity hashes (printed verbatim by the individual phase scripts)')
    for x in ['phase0','phase1','phase2','phase3b','phase4']:
        v=d[x]
        add('`'+v['verify_hash']+'`' if v and v.get('verify_hash') else f'`VERIFY_HASH[{x.upper()}]: NOT MEASURED`')
    add('The FNV-1a 64-bit fingerprint uses this exact UTF-8 payload: `task_id|student_id|P_log|metric1:.4f|metric2:.4f`, with wraparound modulo 2^64. Phase 0 uses corrected and gross clock-call cost; Phases 1–4 use the specific measured metrics below. A hash proves consistency of reported values with its payload; it does **not** prove independent physical execution.')

    add('\n## 1. False sharing, stride sensitivity, Karp–Flatt')
    add('We used one 4096-byte `SharedMemory` buffer and one `ctypes.c_uint64` slot per process, with slot index `worker_id × stride`. The fixed total loop count is M = 24,000,000 and the benchmark collects two warmups and seven timed runs in FULL mode.')
    p1=d['phase1']
    if p1:
        add(f'Actual experiment loop count: {p1["M"]:,}; warmups: {p1["warmups"]}, timed runs: {p1["timed_runs"]}.')
        add('### Table 1A — Stride sensitivity at p = P_phys')
        add(md_table(['Stride (words)','Separation (B)','Median T (ms)','IQR (ms)','Throughput (Mops/s)'],[
            [r['stride_words'],r['separation_bytes'],num(r['median_ms'],3),num(r['iqr_ms'],3),num(r['throughput_mops'],3)] for r in p1['stride_sweep']]))
        gaps=[]
        for left,right in zip(p1['stride_sweep'],p1['stride_sweep'][1:]):
            improvement=100*(left['median_ms']-right['median_ms'])/left['median_ms']
            gaps.append((improvement,right['separation_bytes']))
        drop,offset=max(gaps)
        if drop>10:
            add(f'**Largest observed stride improvement:** when slot separation reached {offset} bytes, median time fell {num(drop,2)}% relative to the preceding tested stride. The OS reported cache-line width '+raw(p0['hardware'].get('cacheline_bytes') if p0 else None)+' bytes. This alone does not establish a physical coherence boundary without repeatability checks.')
        else:
            add(f'**No convincing sharp stride drop was observed.** The largest adjacent improvement was only {num(max(drop, 0),2)}% at a separation of {offset} bytes; this is not sufficient to infer a cache-line boundary. The OS-reported cache-line width is '+raw(p0['hardware'].get('cacheline_bytes') if p0 else None)+' bytes.')
        add('### Table 1B — Process sweep and experimental serial fraction')
        for key in ('1','16'):
            rows=p1['scaling'][key]
            add(f'**Stride = {key} word(s):**')
            add(md_table(['p','T_p (ms)','S_p','E_p','Karp–Flatt e(p)'],[
                [r['p'],num(r['median_ms'],3),num(r['speedup']),num(r['efficiency']),num(r['karp_flatt_e'])]
                for r in rows]))
        last1=p1['scaling']['1'][-1]['karp_flatt_e']
        last16=p1['scaling']['16'][-1]['karp_flatt_e']
        add('Calculations: `S_p=T_1/T_p`, `E_p=S_p/p`, `e(p)=(1/S_p−1/p)/(1−1/p)` for `p>=2`. The p=1 fraction is mathematically undefined.')
        add(f'At the last measured worker count, `e_stride1={num(last1)}` and `e_stride16={num(last16)}`. '+('The higher stride-1 fraction is consistent with more coherence-related overhead from false sharing.' if last1 is not None and last16 is not None and last1>last16 else 'The measured fractions do not show a larger effective serial fraction for stride 1; spawning cost, cache topology, or statistical variance may mask the expected penalty.'))
        add('False sharing occurs when workers write different 8-byte slots that occupy the same hardware coherence line. Cache invalidation traffic can raise memory latency even without a software data race. Karp–Flatt e(p) captures **effective** non-parallel overhead (including synchronization and memory effects), not just strictly serial source lines.')
    else: add('**Phase 1 tables and empirical conclusion require local execution.**')

    add('\n## 2. Amdahl strong scaling and Gustafson weak scaling')
    add('Stage A runs in the parent process over the first 5% of N and performs six sin/sqrt pairs (12 math calls) per element. Stage B splits all N elements across a persistent process pool and applies 35 mixed floating-point/trigonometric iterations per element. Pool construction happens outside the timed region.')
    add('Fixed strong-scaling N = 1,600,000. Weak-scaling workload N(p) = p × 250,000. Every integer p from 1 to P_log is benchmarked.')
    p2=d['phase2']
    if p2:
        add(f'Actual strong N={p2["strong_N"]:,}; weak N0={p2["weak_N0"]:,}.')
        add('### Table 2A — Strong scaling')
        add(md_table(['p','N','T_p (ms)','Speedup S_p','Efficiency E_p','Stage A (ms)'],[
            [r['p'],r['N'],num(r['median_ms'],3),num(r['speedup']),num(r['efficiency']),num(r['serial_stage_median_ms'],3)] for r in p2['strong']]))
        add('### Table 2B — Weak scaling')
        add(md_table(['p','N(p)','T_p (ms)','Weak E','α(p)','Gustafson S_G(p)'],[
            [r['p'],r['N'],num(r['median_ms'],3),num(r['weak_efficiency']),num(r['alpha']),num(r['gustafson_speedup'])] for r in p2['weak']]))
        add('Amdahl formula: `S_A(p)=1/[s+(1−s)/p]` where `s=T_StageA(1)/T_strong(1)`. Gustafson formula: `S_G(p)=p−α(p)(p−1)` where `α(p)=T_StageA(p)/T_weak(p)`. Weak efficiency: `T_weak(1)/T_weak(p)`.')
        add(f'Calculated serial fraction s = **{num(p2["serial_fraction"],6)}**; theoretical asymptotic limit `S_infinity=1/s` = **{num(p2["amdahl_infinity"])}**; Amdahl at P_log = **{num(p2["amdahl_plog"])}**; empirical strong speedup at P_log = **{num(p2["strong"][-1]["speedup"])}**; Gustafson scaled speedup at P_log = **{num(p2["weak"][-1]["gustafson_speedup"])}**.')
        boundary=p2['boundary']
        if boundary['status']=='measured':
            add(f'At the physical-to-logical-core boundary p={boundary["p_boundary"]}, marginal improvement falls from ΔS={num(boundary["marginal_gain_before"])} to ΔS={num(boundary["marginal_gain_after"])}; relative reduction is {num(boundary["percentage_drop"],2)}% (a negative result indicates an increase).')
        else:
            add('**SMT boundary:** '+boundary['status']+'. This machine may have no extra logical threads beyond physical cores, so the exact p=P_phys+1 point cannot be reported.')
        clusters=(p0 or {}).get('hardware',{}).get('core_clusters') or {}
        if len(clusters)>=2:
            try:
                # Use the first large-cache cluster as an architectural reference;
                # the OS scheduler is NOT pinned to cores by the experiment.
                high_cache=max(clusters.values(),key=lambda cl:int(cl.get('l2_bytes') or 0))
                k=int(high_cache['physical_cores'])
                series={int(r['p']):r['speedup'] for r in p2['strong']}
                if 2<=k and k+1 in series and k-1 in series:
                    before=series[k]-series[k-1]
                    after=series[k+1]-series[k]
                    change=100*(before-after)/before if before else None
                    add(f'**Hybrid cluster inflection (empirical):** the larger-L2 cluster has {k} physical cores. Marginal strong-scaling speedup from p={k-1} to {k} was ΔS={num(before,4)}, while from p={k} to {k+1} it was ΔS={num(after,4)}, a {num(change,2)}% decrease. Worker-to-core affinity was not measured or pinned; this is an observed worker-count inflection, not proof of exact P/E-core placement.')
            except (ValueError, KeyError, TypeError, ZeroDivisionError):
                add('Hybrid cluster topology was reported but the marginal speedup boundary could not be quantified from available measurements.')
        add('Real scaling departs from ideal predictions because of process-pool IPC, CPU frequency variation, cache pressure, thermal throttling, and potentially heterogeneous performance/efficiency cores. Observed values, not the model, determine conclusions.')
    else: add('**Phase 2 scaling matrices and calculations require local measurements.**')

    add('\n## 3. Empirical Roofline and three-stage matrix optimization')
    add('### 3A — DRAM bandwidth and Python arithmetic ceiling')
    add('Each FULL benchmark uses two 96,000,000-byte shared buffers (192,000,000 total bytes). A copy reads one source byte and writes one destination byte. `BW_GB/s=(2×96×10^6)/(T_seconds×10^9)`. An unrolled 16-scalar Python kernel counts two arithmetic FLOPs for each multiply-add update; its observed rate is `P_GFLOP/s=(workers × 80×10^6)/(T_seconds×10^9)`. The ridge is `I*=P/BW`.')
    p3a=d['phase3a']
    if p3a:
        add(md_table(['Hardware roofline parameter','Measured value'],[
            ('A and B buffer size (bytes each)',p3a['buffer_bytes_each']),
            ('Total footprint (bytes)',p3a['working_set_bytes']),
            ('Memory copy T_median (ms)',num(p3a['bw_median_ms'],3)),
            ('Sustained BW (GB/s)',num(p3a['bandwidth_gbps'],6)),
            ('Computed FLOPs per worker',f'{p3a["flops_each"]:,}'),
            ('Compute T_median (ms)',num(p3a['compute_median_ms'],3)),
            ('Python ceiling P (GFLOP/s)',num(p3a['compute_gflops'],6)),
            ('Ridge I* (FLOPs/byte)',num(p3a['ridge_flops_per_byte'],6))]))
        add('**Methodological limit:** Python expressions `x*a+b` are not guaranteed to become hardware-fused FMA instructions. These are interpreted Python throughput ceilings, not a hardware FLOP peak. Pool IPC and timing overhead can also affect both ceilings.')
    else: add('**Phase 3A measured bandwidth, compute and ridge missing.**')
    add('### 3B — GEMM i-j-k / i-k-j / six-loop tiling')
    add('Matrices are row-major flat double-precision shared arrays. Full N=384, so arithmetic work is `2×N^3` FLOPs. Variant 1 uses i-j-k (strided reads from B); Variant 2 uses i-k-j (contiguous B and C accesses). Variant 3 uses ii-jj-kk-i-k-j tiling with the same i-k-j microkernel. Workers own disjoint C rows. All 10 prescribed tile sizes are evaluated.')
    p3=d['phase3b']
    if p3:
        add(f'Actual N={p3["N"]}; p={p3["p"]}; warmups={p3["warmups"]}; timed runs={p3["timed_runs"]}.')
        add(md_table(['Variant','BS','T_median (ms)','GFLOP/s','W_tile (B)','I assumed (FLOPs/B)','Attainable GFLOP/s','Ceiling achieved (%)','Max error vs reorder'],[
            [r['variant'],r['BS'] or '—',num(r['median_ms'],3),num(r['gflops'],6),
             raw(r.get('tile_working_set_bytes','—')),num(r['assumed_intensity_flops_per_byte'],5),
             num(r['roofline_attainable_gflops'],6),num(r['roofline_attainment_pct'],2),
             num(r.get('validation_max_abs_error'),10) if r['variant']=='blocked' else '—']
            for r in p3['variants']]))
        best=p3['best_bs']; footprint=3*best*best*8
        add(f'Best empirically observed tile BS* = **{best}**, with throughput **{num(p3["best_gflops"],6)} GFLOP/s**. Its three-tile footprint `W_tile=3×BS²×8` = **{footprint:,} bytes**; estimated tiled intensity `I_tile=BS/12` = **{num(p3["intensity_best"],5)} FLOPs/byte**. Naive assumed intensity is 0.125 FLOP/byte.')
        naive_result=next(r for r in p3['variants'] if r['variant']=='naive')
        if p3['best_gflops'] < naive_result['gflops']:
            penalty=100*(naive_result['gflops']-p3['best_gflops'])/naive_result['gflops']
            add(f'**Observed optimization outcome:** the best blocked version was {num(penalty,2)}% slower than naive GEMM ({num(p3["best_gflops"],6)} vs {num(naive_result["gflops"],6)} GFLOP/s). In pure Python, interpreter-level loop and indexing overhead may exceed the cache-locality benefit. This experiment does not establish a blocked speedup.')
        else:
            gain=100*(p3['best_gflops']/naive_result['gflops']-1)
            add(f'**Observed optimization outcome:** the best blocked variant was {num(gain,2)}% faster than naive GEMM.')
        h=p0['hardware'] if p0 else {}
        l1,l2=h.get('l1d_bytes'),h.get('l2_bytes')
        for nm,cap in [('L1d',l1),('L2',l2)]:
            if cap: add(f'Tile footprint versus {nm}={cap:,} B: '+('fits nominal capacity.' if footprint<=cap else 'exceeds nominal capacity.')+' Actual capacity also holds code, stack and other active data.')
            else: add(f'{nm} capacity was not reported, so nominal fit cannot be established.')
        add('Roofline model: `P_attainable(I)=min(P_sustained, BW_sustained×I)` and `%attained=100×GFLOP/s_measured/P_attainable`. The reordered variant uses 0.125 FLOP/byte only as a **conservative nominal reference**: its true operational intensity is not specified by the task or measured by hardware counters. A value above 100% flags a model mismatch, not an impossible measured observation.')
        add('Numerical validation: all blocked variants are compared element-by-element against Variant 2; their largest absolute differences must be strictly less than 1e−9. All reported tile runs passed this in the generated results.' if all(r.get('equivalent_to_reordered',True) for r in p3['variants']) else '**Numerical validation failed.**')
    else: add('**Phase 3B GEMM sweep, best tile, validation and cache-footprint comparison require local execution.**')

    add('\n## 4. Skewed scheduling and load imbalance')
    add('Full workload has N=12,000 outer items, with `K(i)=1+floor((i/60)^2)=1+(i*i//3600)` trigonometric iterations per item. Strategy 1 uses contiguous static blocks; Strategy 2 round-robin cyclic assignment; Strategy 3 a synchronized shared index with dynamic chunk sizes C∈{1,4,16,64,256,1024}. All trials use P_phys processes.')
    add('`lambda = max_t(t_worker[t]) / ((sum_t t_worker[t])/p)`. Active worker times exclude idle lock-wait periods; wall time includes process startup and dispatch. Values close to 1 imply balanced useful compute times.')
    p4=d['phase4']
    if p4:
        add(f'Actual workload N={p4["N"]:,}, physical workers={p4["p"]}, warmups={p4["warmups"]}, timed runs={p4["timed_runs"]}.')
        add(md_table(['Scheduling strategy','Chunk C','Median wall time (ms)','IQR (ms)','λ (active load imbalance)'],[
            [r['strategy'],r['chunk'] or '—',num(r['median_ms'],3),num(r['iqr_ms'],3),num(r['imbalance_lambda'],5)] for r in p4['results']]))
        add('### Individual active worker times (representative median trial)')
        for r in p4['results']:
            add(f'- **{r["strategy"]} C={raw(r["chunk"])}:** '+', '.join(f'W{j}={num(x,2)} ms' for j,x in enumerate(r['worker_active_ms'])))
        best=next(r for r in p4['results'] if r['strategy']=='dynamic' and r['chunk']==p4['best_dynamic_chunk'])
        block=p4['results'][0]; cyclic=p4['results'][1]
        c1=next(r for r in p4['results'] if r['strategy']=='dynamic' and r['chunk']==1)
        c1024=next(r for r in p4['results'] if r['strategy']=='dynamic' and r['chunk']==1024)
        add(f'**Optimal measured dynamic chunk C* = {p4["best_dynamic_chunk"]}** with {num(best["median_ms"],3)} ms wall time. Static block = {num(block["median_ms"],3)} ms; cyclic = {num(cyclic["median_ms"],3)} ms.')
        add(f'At C=1: T={num(c1["median_ms"],3)} ms, λ={num(c1["imbalance_lambda"])}. At C=1024: T={num(c1024["median_ms"],3)} ms, λ={num(c1024["imbalance_lambda"])}. Small chunks usually reduce remaining uneven work but increase lock acquisitions and contention; large chunks reduce lock traffic but can leave high-cost items on one worker. The recorded table, rather than an assumed optimum, determines C*.')
    else: add('**Phase 4 load imbalance observations require local execution.**')

    add('\n## 5. Raw local terminal telemetry')
    if not available:
        add('**No locally executed terminal logs available in this initial package.**')
    for key in ['phase0','phase1','phase2','phase3a','phase3b','phase4']:
        log=Path(results_dir)/(key+'.log')
        if log.exists():
            add(f'### {key}.log')
            add('```text')
            add(log.read_text(encoding='utf-8',errors='replace').rstrip())
            add('```')
        else: add(f'**{key}.log:** Not run.')
    add('\n## 6. Reproduction and limitations')
    add('Execute `python3 run_all.py --student-id '+str(student_id)+' --mode full` from this directory, on the target laptop. The runner writes JSON and console log evidence for every phase, then regenerates this Markdown report. The `--mode smoke` option tests only code execution with reduced workload and is **not acceptable as the requested empirical full run**.')
    add('The study uses wall-clock observations on a real machine; CPU availability, power mode, resource limits, thermal history, cross-process startup and OS scheduling introduce noise. Median and IQR are reported when available. Clock calibration alone does not remove those effects. No performance observation is extrapolated from another machine.')
    add('**Assignment restriction:** the source PDF says the work must be performed offline, solo and without AI tools. This prepared package is assistance and does not replace the required independently executed lab. Follow your instructor’s academic-integrity requirements when choosing what to submit.')
    if include_source:
        add('\n## Appendix A — Complete Python 3 implementation')
        scripts=['harness.py','task0_cal.py','task1_falsesharing.py',
                 'task2_scaling.py','task3a_roofline.py','task3b_gemm.py',
                 'task4_scheduling.py','run_all.py','build_report.py']
        for name in scripts:
            path=Path(source_dir)/name
            if path.exists():
                add(f'### `{name}`')
                add('```python')
                add(path.read_text(encoding='utf-8').rstrip())
                add('```')
    outfile=Path(outfile)
    outfile.parent.mkdir(parents=True,exist_ok=True)
    outfile.write_text('\n\n'.join(lines)+'\n',encoding='utf-8')
    return available,full


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--student-id',type=int,default=230103081)
    parser.add_argument('--results-dir',default='results')
    parser.add_argument('--output',default=None)
    parser.add_argument('--no-source',action='store_true')
    args=parser.parse_args()
    src=Path(__file__).resolve().parent
    name=args.output or str(src/f'lab_report_{args.student_id}.md')
    available,complete=generate(args.results_dir,args.student_id,name,src,not args.no_source)
    print('REPORT:',name,'EXPERIMENT FILES:',available,'COMPLETE FULL:',complete)

if __name__=='__main__':
    main()
